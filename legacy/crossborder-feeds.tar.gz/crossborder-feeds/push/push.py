#!/usr/bin/env python3
"""
每日推送：从 FreshRSS 拉取最近未读 → 可选 AI 摘要 → 推送到 Telegram / 企业微信。

FreshRSS 侧准备：
  设置 → 身份验证 → 勾选"允许 API 访问"，并设置一个 API 密码。
  本脚本用 FreshRSS 的 Google Reader 兼容 API。

用环境变量配置（见下方 .env.example）。配好后用 cron 每天定时跑，例如：
  0 9 * * *  cd /path/to/push && python3 push.py >> push.log 2>&1
"""
import os
import sys
import json
import time
import urllib.parse
import requests

FRESHRSS_URL = os.environ["FRESHRSS_URL"].rstrip("/")      # 如 http://freshrss
FRESHRSS_USER = os.environ["FRESHRSS_USER"]
FRESHRSS_API_PASSWORD = os.environ["FRESHRSS_API_PASSWORD"]
MAX_ITEMS = int(os.environ.get("PUSH_MAX_ITEMS", "20"))

# 推送渠道（至少配一个）
TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN")
TG_CHAT_ID = os.environ.get("TG_CHAT_ID")
WECOM_WEBHOOK = os.environ.get("WECOM_WEBHOOK")            # 企业微信群机器人 webhook

# AI 摘要（可选）。留空则只推标题+链接。兼容 Anthropic / OpenAI 风格端点。
AI_API_URL = os.environ.get("AI_API_URL")                 # 如 https://api.anthropic.com/v1/messages
AI_API_KEY = os.environ.get("AI_API_KEY")
AI_MODEL = os.environ.get("AI_MODEL", "claude-3-5-haiku-latest")


def greader_login():
    """获取 Google Reader API 的 auth token。"""
    r = requests.post(
        f"{FRESHRSS_URL}/api/greader.php/accounts/ClientLogin",
        data={"Email": FRESHRSS_USER, "Passwd": FRESHRSS_API_PASSWORD},
        timeout=20,
    )
    r.raise_for_status()
    for line in r.text.splitlines():
        if line.startswith("Auth="):
            return line[len("Auth="):]
    raise RuntimeError("登录失败，检查用户名/API 密码以及是否开启 API 访问")


def fetch_unread(auth):
    """拉取未读条目（按时间倒序）。"""
    headers = {"Authorization": f"GoogleLogin auth={auth}"}
    params = {
        "n": MAX_ITEMS,
        "xt": "user/-/state/com.google/read",      # 排除已读
        "r": "n",                                   # 最新优先
        "output": "json",
    }
    url = f"{FRESHRSS_URL}/api/greader.php/reader/api/0/stream/contents/user/-/state/com.google/reading-list"
    r = requests.get(url, headers=headers, params=params, timeout=30)
    r.raise_for_status()
    items = []
    for it in r.json().get("items", []):
        items.append({
            "title": it.get("title", "(无标题)"),
            "url": (it.get("canonical") or it.get("alternate") or [{}])[0].get("href", ""),
            "source": it.get("origin", {}).get("title", ""),
        })
    return items


def ai_summarize(items):
    """把今天的标题列表交给模型做一段中文要点。失败则返回 None，回退到纯列表。"""
    if not (AI_API_URL and AI_API_KEY):
        return None
    headlines = "\n".join(f"- [{it['source']}] {it['title']}" for it in items)
    prompt = (
        "下面是今天跨境电商与国际物流的资讯标题。请用中文输出 5-8 条要点，"
        "按重要性排序，合并重复主题，每条一句话，突出平台政策/费用/物流变动。"
        f"\n\n{headlines}"
    )
    try:
        if "anthropic" in AI_API_URL:
            headers = {
                "x-api-key": AI_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            }
            body = {
                "model": AI_MODEL,
                "max_tokens": 800,
                "messages": [{"role": "user", "content": prompt}],
            }
            r = requests.post(AI_API_URL, headers=headers, json=body, timeout=60)
            r.raise_for_status()
            return "".join(b.get("text", "") for b in r.json().get("content", []))
        else:  # OpenAI 兼容（豆包/DeepSeek/OpenAI 等）
            headers = {"Authorization": f"Bearer {AI_API_KEY}", "content-type": "application/json"}
            body = {
                "model": AI_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 800,
            }
            r = requests.post(AI_API_URL, headers=headers, json=body, timeout=60)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
    except Exception as e:
        print(f"[warn] AI 摘要失败，回退纯列表：{e}", file=sys.stderr)
        return None


def build_message(items, summary):
    date = time.strftime("%Y-%m-%d")
    parts = [f"📦 跨境/物流日报 {date}", ""]
    if summary:
        parts += [summary.strip(), "", "—— 原文 ——"]
    for it in items:
        src = f"[{it['source']}] " if it["source"] else ""
        parts.append(f"• {src}{it['title']}\n  {it['url']}")
    return "\n".join(parts)


def push_telegram(text):
    if not (TG_BOT_TOKEN and TG_CHAT_ID):
        return
    # Telegram 单条上限 4096 字符，超长则分段
    for chunk in [text[i:i + 3800] for i in range(0, len(text), 3800)]:
        requests.post(
            f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT_ID, "text": chunk, "disable_web_page_preview": True},
            timeout=30,
        ).raise_for_status()


def push_wecom(text):
    if not WECOM_WEBHOOK:
        return
    for chunk in [text[i:i + 1900] for i in range(0, len(text), 1900)]:
        requests.post(
            WECOM_WEBHOOK,
            json={"msgtype": "text", "text": {"content": chunk}},
            timeout=30,
        ).raise_for_status()


def main():
    auth = greader_login()
    items = fetch_unread(auth)
    if not items:
        print("没有未读条目，跳过推送")
        return
    summary = ai_summarize(items)
    msg = build_message(items, summary)
    push_telegram(msg)
    push_wecom(msg)
    print(f"已推送 {len(items)} 条" + ("（含 AI 摘要）" if summary else ""))


if __name__ == "__main__":
    main()
